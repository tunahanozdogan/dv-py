Matplotlib görselleştirme kütüphanesinin özelliklerini uygulamalı bir şekilde anlatan çalışma dosyam.



Yazı dizisi için:

[https://medium.com/datarunner/veri-gorsellestirme/home](https://medium.com/datarunner/veri-gorsellestirme/home)

Dosya jupyter uzantılı olduğu için githubda açılırken sıkıntı yaşıyorsanız bu linkten ön izleme yapabilirsiniz.

https://nbviewer.jupyter.org/github/mertalabas/matplotlib_tutorial/blob/master/Matplotlib_tutorial.ipynb 

